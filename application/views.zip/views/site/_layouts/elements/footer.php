<div class="container small mt-5">
    <div class="text-muted text-center">
        <?php echo $this->config->item('app_admin_copy_right');?>
    </div>
    <div class="small text-muted text-center">
        App Ver. <?php echo $this->config->item('app_admin_ui_version');?>
    </div>
</div>