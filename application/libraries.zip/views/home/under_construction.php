<div class="row heading-container">
    <div class="col-12">
        <h1 class="page-header"><?php echo isset($row['pagecontent_title']) ? $row['pagecontent_title'] : '';?></h1>
    </div>
</div><!--/.heading-container-->

<p></p>